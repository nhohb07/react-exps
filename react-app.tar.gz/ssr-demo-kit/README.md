# Server-side rendering demo kit

Each folder contains a separate demo.

These examples are part of the *"Server-Side Rendering of Isomorphic Apps at SoundCloud"* talk given [Level Up](http://levelupcon.com/) on Oct. 8, 2014.

Get the [slides](https://github.com/zertosh/ssr-demo-kit/raw/master/Server-Side%20Rendering%20of%20Isomorphic%20Apps%20at%20SoundCloud.pdf) and/or watch the [video](http://vimeo.com/108488724).
