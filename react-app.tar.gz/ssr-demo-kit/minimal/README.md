# "minimal" demo app

## Requirements

[node.js](http://nodejs.org/download/)

## Running

Install the dependencies:

```
npm install
```

Compile the assets and start the server:

```
npm run web
```

Then go to [http://localhost:8000](http://localhost:8000)
