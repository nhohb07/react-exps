# Feedback

We appreciate feedback from the community. You can post feature requests and bug reports on [Product Pains](https://productpains.com/product/redux).

<iframe width="100%" height="400px" scrolling="no" frameBorder="0" src="https://productpains.com/widget.html?token=07268479-03f5-d5b8-2626-0320223ff1ee"></iframe>
<script type="text/javascript" src="https://productpains.com/js/lib/iframeResizer.min.js"></script>
