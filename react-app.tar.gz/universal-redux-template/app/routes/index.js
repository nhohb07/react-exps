if (typeof require.ensure !== 'function') require.ensure = (d, c) => c(require)

import React from 'react';
import { Provider } from 'react-redux';

import App from 'containers/App';
import Intro from 'containers/Intro';

export default {
  path: '/',
  component: App,
  getChildRoutes(location, cb) {
    require.ensure([], (require) => {
      cb(null, {
        path: '/q/:questionId/:questionTitle',
        component: require('containers/Question').default
      })
    })
  },
  indexRoute: {
    component: Intro
  }
}