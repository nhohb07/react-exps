require('babel-register');
require('./server.js');
