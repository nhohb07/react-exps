
0.3.0 / 2016-02-12
==================

[fixed]
 * fix npm start script
 * fix hmr not working issue
 * fix express warning

[changed]
 * upgrade `engines.node` to 5.6.1
 * upgrade `engines.npm` to 3.6.0
 * upgrade babel and its friends to 6
 * upgrade babel-plugin-rewire

0.2.0 / 2016-01-24
==================

[added]
  * add stylesheets using scss with gulp



0.1.0 / 2015-12-31
==================

 * first semi-stable version
