import React from 'react';
import Main from '../layout/main';

class User extends React.Component {
  render() {
    return (
      <Main>
        <h2>User Detail</h2>
      </Main>
    );
  };
};

module.exports = User;
