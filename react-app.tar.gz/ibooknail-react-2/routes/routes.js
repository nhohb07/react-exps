import {ListYourSalon} from '../components/Salon';

module.exports.ListYourSalon = {
  path: 'list-your-salon/:step',
  component: ListYourSalon
};